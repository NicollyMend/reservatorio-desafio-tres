#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/adc.h"
#include "driver/gpio.h"

#define LED_GPIO_1 GPIO_NUM_2  // LED1
#define LED_GPIO_2 GPIO_NUM_4  // LED2
#define LED_GPIO_3 GPIO_NUM_5  // LED3
#define LED_GPIO_4 GPIO_NUM_18 // LED4
#define BUZZER_GPIO GPIO_NUM_19 // Buzzer

#define ADC_CHANNEL ADC1_CHANNEL_0  // Canale de medição do sensor

void config_adc() {
    adc1_config_width(ADC_WIDTH_BIT_12);  // 12 bits de resolução
    adc1_config_channel_atten(ADC_CHANNEL, ADC_ATTEN_DB_0);  // Atenuação de 0 dB (0-3.3V)
}

void config_gpio() {
    gpio_set_direction(LED_GPIO_1, GPIO_MODE_OUTPUT);
    gpio_set_direction(LED_GPIO_2, GPIO_MODE_OUTPUT);
    gpio_set_direction(LED_GPIO_3, GPIO_MODE_OUTPUT);
    gpio_set_direction(LED_GPIO_4, GPIO_MODE_OUTPUT);
    gpio_set_direction(BUZZER_GPIO, GPIO_MODE_OUTPUT);
}

void app_main() {
    config_adc();
    config_gpio();
    
    while (1) {
        int adc_value = adc1_get_raw(ADC_CHANNEL);  // Leitura do valor do sensor
        float percentual = (adc_value / 4095.0) * 100.0;  // Conversão para percentual

        printf("Nível de água: %.2f%%\n", percentual);

        // Definir LEDs e buzzer com base no nível
        if (percentual < 4.0) {
            // Nível crítico - abaixo de 4%
            gpio_set_level(LED_GPIO_1, 1);  // Acende LED1
            gpio_set_level(LED_GPIO_2, 0);  // Desliga LED2
            gpio_set_level(LED_GPIO_3, 0);  // Desliga LED3
            gpio_set_level(LED_GPIO_4, 0);  // Desliga LED4
            gpio_set_level(BUZZER_GPIO, 1); // Aciona o buzzer
        } else if (percentual < 12.0) {
            // Operação com bombeamento - nível abaixo de 12%
            gpio_set_level(LED_GPIO_1, 0);  // Desliga LED1
            gpio_set_level(LED_GPIO_2, 1);  // Acende LED2
            gpio_set_level(LED_GPIO_3, 0);  // Desliga LED3
            gpio_set_level(LED_GPIO_4, 0);  // Desliga LED4
            gpio_set_level(BUZZER_GPIO, 0); // Desliga o buzzer
        } else if (percentual < 70.0) {
            // Funcionamento ótimo
            gpio_set_level(LED_GPIO_1, 0);  // Desliga LED1
            gpio_set_level(LED_GPIO_2, 0);  // Desliga LED2
            gpio_set_level(LED_GPIO_3, 1);  // Acende LED3
            gpio_set_level(LED_GPIO_4, 0);  // Desliga LED4
            gpio_set_level(BUZZER_GPIO, 0); // Desliga o buzzer
        } else if (percentual < 95.0) {
            // Operação com comportas de drenagem abertas - nível acima de 70%
            gpio_set_level(LED_GPIO_1, 0);  // Desliga LED1
            gpio_set_level(LED_GPIO_2, 0);  // Desliga LED2
            gpio_set_level(LED_GPIO_3, 0);  // Desliga LED3
            gpio_set_level(LED_GPIO_4, 1);  // Acende LED4
            gpio_set_level(BUZZER_GPIO, 0); // Desliga o buzzer
        } else {
            // Alerta de transbordamento - nível acima de 95%
            gpio_set_level(LED_GPIO_1, 0);  // Desliga LED1
            gpio_set_level(LED_GPIO_2, 0);  // Desliga LED2
            gpio_set_level(LED_GPIO_3, 0);  // Desliga LED3
            gpio_set_level(LED_GPIO_4, 1);  // Acende LED4
            gpio_set_level(BUZZER_GPIO, 1); // Aciona o buzzer
        }

        vTaskDelay(1000 / portTICK_PERIOD_MS);  // Atraso de 1 segundo
    }
}
